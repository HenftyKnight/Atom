// NAME           : Rushabh Prajapati
// ASSIGNMENT 2
// INSTRUCTOR     : Calin Anton
// LAB INSTRUCTOR : Saleh Hanan
// PURPOSE        : write a couple of compare functions to 
//                 use with qsort on an array (of struct game). 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//  Structure for storing the price and title of the game into an array
typedef struct {
 double price;
 char title[60];
} game;

// ascending alphabetical order of the price field
int compGamesByPrice(game *g1, game *g2){
    return (g1->price > g2->price);

}

// ascending alphabetical order of the title field
int compGamesByTitle(game *g1, game * g2){
    return strcmp(g1->title, g2->title);
}

int main(){
    int i; 
    game element[7]; // Creating an array of type game to store price and title.

    // Adding values in the array element, for price simply using methods of structure
    // As value cannot be asigned to string, we are using strcpy

    element[0].price = 22.79;
    strcpy(element[0].title, "Opus Magnum");

    element[1].price = 0.01;
    strcpy(element[1].title, "Minecraft");

    element[2].price = 7.79;
    strcpy(element[2].title, "TIS-100");

    element[3].price = 14.99;
    strcpy(element[3].title, "Trainz");

    element[4].price = 0.00;
    strcpy(element[4].title, "Code Combat");

    element[5].price = 7.79;
    strcpy(element[5].title, "Lemmings Revolution");

    element[6].price = 64.96;
    strcpy(element[6].title, "Warcraft");

    //  Printing all the data, 1) is the original list i.e UNSORTED
    printf("+-------------------------------------------------------------------------+\n");
    printf("|");
    printf("\t\t\t\t\t\tOriginal List\t\t\t\t\t\t\t\t\t\n");
    printf("+-------------------------------------------------------------------------+\n");
    printf("Position  |\tPrice\t|\tTitle\t\t\t\n");
    for(i = 1; i < 8; i++)
        printf("%d \t\t|\t%.2f \t|\t%s   \t\t\n", i, element[i-1].price, element[i-1].title);
    printf("\n\n");
    printf("+-------------------------------------------------------------------------+\n");
    printf("|\t\t\t\t\t\tQsort by Price   \t\t\t\t\t\t\t\t\t\n");
    printf("+-------------------------------------------------------------------------+\n");
   
   
   // Printing the table again using qsort function on the price, for that helper function compGamesByPrice
   // using size variable to get the size of each array element
   // sizeof() for the size of the structure 
    printf("Position  |\tPrice\t|\tTitle\t\t\t\n");
    
    size_t size = sizeof(element)/ sizeof(element[0]);

    qsort(element, 7, sizeof(game), compGamesByPrice);

    for(i = 1; i < 8; i++)
        printf("%d \t\t|\t%.2f \t|\t%s   \t\t\n", i, element[i-1].price, element[i-1].title);

    printf("+-------------------------------------------------------------------------+\n");
   
    printf("\n\n");

     // Printing the table again using qsort function on the TITLE, for that helper function compGamesByTitle
    // using size variable to get the size of each array element
    // sizeof() for the size of the structure 
    // compsGamesByTitle uses strcmp(), a function in string.h file for sorting strings

    printf("+-------------------------------------------------------------------------+\n");
    printf("|\t\t\t\tQsort by Title   \t\t\t\t\t\t\t\t\t\t\n");
    printf("+-------------------------------------------------------------------------+\n");
    printf("Position  |\tPrice\t|\tTitle\t\t\t\n");
    
    qsort(element, 7, sizeof(game), compGamesByTitle);

    for(i = 1; i < 8; i++)
        printf("%d \t\t|\t%.2f \t|\t%s   \t\t\n", i, element[i-1].price, element[i-1].title);

    return 0;    
        
}
