// NAME           : Rushabh Prajapati
// ASSIGNMENT 2
// INSTRUCTOR     : Calin Anton
// LAB INSTRUCTOR : Saleh Hanan
// PURPOSE        : Create a representation of ginp-gonp scores which uses only 1 byte; 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lab6Exercise2.h"

//  Prints the the scroes of the players in the format A:B
void printGG(ginp_gonp s){
   printf ("%d : %d\n", s.ginp_scores_p1, s.ginp_scores_p2);
}

// Opens a file name and writes into the file name in binary
void writeGG(ginp_gonp s, char * fileName){
    FILE *fp;
    fp = fopen (fileName, "wb");      // opening a file name
    if (fp == NULL)                  // error checking
    { 
        fprintf(stderr, "\nError opend file\n"); 
        exit (1); 
    }

    fwrite (&s, sizeof(ginp_gonp), 1, fp); // Writing into the file 
    fclose(fp);
}

// Reads the binary file and returns the ginp_gonp
ginp_gonp readGG(char * fileName){
    FILE *fp_1;                     // File for reading a binary file
    ginp_gonp player_scores;        // Structure for reading the scores
    fp_1 = fopen (fileName, "rb");  // opening the file for reading

    if (fp_1 == NULL) {             // error checking
      fprintf(stderr, "\nError to open the file\n");
      exit (1);
   }
    // fread() to read the file
    fread(&player_scores, sizeof(ginp_gonp), 1, fp_1);
    fclose(fp_1);                   // closing the file
    return player_scores;
   
}


int main(){
   ginp_gonp scores;

   scores.ginp_scores_p1 = 1;   // Manually Assigning scores to the struct
   scores.ginp_scores_p2 = 2;

   writeGG(scores, "scores.dat");    // Writing scores using writeGG

   readGG("scores.dat");                    // Reading the binary file
   
   printGG(scores);                  // Printing the scores

}
