// NAME           : Rushabh Prajapati
// ASSIGNMENT 2
// INSTRUCTOR     : Calin Anton
// LAB INSTRUCTOR : Saleh Hanan
// PURPOSE        : Header file for lab6Exercise2.c
#ifndef LAB6_EXERCISE_2_H
#define LAB6_EXERCISE_2_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char ginp_scores_p1:4 ;  // Representation of 1 byte
    char ginp_scores_p2:4 ;         
}ginp_gonp;

/*
Function : printGG(char *fileName)
prints a score in your representation in the format A:B – where A
is the number of rounds won by the first player and B is the number 
of rounds won by the second player; 
*/
void printGG(ginp_gonp s);

/*
Function: writeGG(ginp_gonp s, char * fileName)
Parameter : struct , a file pointer
returns   : Nothing
writes a ginp-gonp score in your representation into a binary file
specified by its name
*/
void writeGG(ginp_gonp s, char * fileName);

/*
Function :readGG(char * fileName)
Parameter: a file pointer
returns : a struct of type ginp_gonp
reads a ginp-gonp score in your representation from a binary file
*/
ginp_gonp readGG(char * fileName);


#endif